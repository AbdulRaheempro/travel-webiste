document.addEventListener('DOMContentLoaded', function () {
    // Header Navigation Hover Effect
    const navItems = document.querySelectorAll('header nav ul li');
    navItems.forEach(item => {
        item.addEventListener('mouseover', () => {
            item.style.backgroundColor = '#3498db'; // Vibrant blue
            item.style.color = '#34495e'; // Darker blue-gray
        });
        item.addEventListener('mouseout', () => {
            item.style.backgroundColor = ''; // Reset background color
            item.style.color = '#ecf0f1'; // Light gray
        });
    });

    // Button Hover Effect
    const buttons = document.querySelectorAll('header .content .cont_bx button, header .trip_bx .search_bx input[type="button"], footer .input button');
    buttons.forEach(button => {
        button.addEventListener('mouseover', () => {
            button.style.transform = 'translateY(5px)';
            if (button.tagName === 'BUTTON') {
                button.style.backgroundColor = '#d35400'; // Darker warm orange
            } else {
                button.style.backgroundColor = '#2c3e50'; // Darker blue-gray
            }
        });
        button.addEventListener('mouseout', () => {
            button.style.transform = '';
            if (button.tagName === 'BUTTON') {
                button.style.backgroundColor = '#e67e22'; // Warm orange
            } else {
                button.style.backgroundColor = '#34495e'; // Darker blue-gray
            }
        });
    });

    // Image Hover Effects
    const images = document.querySelectorAll('header .trip_bx .travel_bx .cards .card img, .offers .cards .card .img_txt img, .destination .img_bx img');
    images.forEach(img => {
        img.addEventListener('mouseover', () => {
            img.style.opacity = '0.8';
            img.style.transform = 'scale(1.05)';
        });
        img.addEventListener('mouseout', () => {
            img.style.opacity = '1';
            img.style.transform = '';
        });
    });

    // Card Hover Effects
    const cards = document.querySelectorAll('header .trip_bx .travel_bx .cards .card, .offers .cards .card');
    cards.forEach(card => {
        card.addEventListener('mouseover', () => {
            card.style.transform = 'scale(1.05)';
            card.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
        });
        card.addEventListener('mouseout', () => {
            card.style.transform = '';
            card.style.boxShadow = '';
        });
    });

    // Offers Section Hover Effect
    const offersSection = document.querySelector('.offers');
    offersSection.addEventListener('mouseover', () => {
        offersSection.style.transform = 'scale(1.02)';
    });
    offersSection.addEventListener('mouseout', () => {
        offersSection.style.transform = '';
    });

    // Destination Hover Effect
    const desBx = document.querySelector('.destination .des_bx');
    desBx.addEventListener('mouseover', () => {
        desBx.style.backgroundColor = '#f5f5f5'; // Light background for hover
        desBx.style.transform = 'scale(1.02)';
    });
    desBx.addEventListener('mouseout', () => {
        desBx.style.backgroundColor = '';
        desBx.style.transform = '';
    });

    // Handle Scroll to Top Button
    const scrollTopBtn = document.createElement('button');
    scrollTopBtn.textContent = 'Scroll to Top';
    scrollTopBtn.style.position = 'fixed';
    scrollTopBtn.style.bottom = '20px';
    scrollTopBtn.style.right = '20px';
    scrollTopBtn.style.padding = '10px 20px';
    scrollTopBtn.style.borderRadius = '20px';
    scrollTopBtn.style.border = 'none';
    scrollTopBtn.style.backgroundColor = '#e67e22'; // Warm orange
    scrollTopBtn.style.color = '#fff'; // White text
    scrollTopBtn.style.cursor = 'pointer';
    scrollTopBtn.style.zIndex = '1000';
    document.body.appendChild(scrollTopBtn);

    scrollTopBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});
